"""
A folder with all the sync extensions.
"""

from .webhooks import SyncWebhookListener


__all__ = [
    "SyncWebhookListener"
]